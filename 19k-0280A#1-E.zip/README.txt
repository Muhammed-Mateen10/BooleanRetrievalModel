Language Used: Python 3.8.10
Used Flask as a backend framework
Used HTML CSS as simple page styling and frontend


